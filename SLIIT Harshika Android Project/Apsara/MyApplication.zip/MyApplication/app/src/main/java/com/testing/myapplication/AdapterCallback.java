package com.testing.myapplication;

public interface AdapterCallback {

    public void onMethodCallback();
}
